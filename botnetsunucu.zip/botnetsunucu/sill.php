<?php

  include("header.php");
ob_start();

					
					
	  
?>
<?php
		
			$cekilen_id=htmlspecialchars(strip_tags($_POST['cekilen_id']));
			$bos;
			$guncelle = $db->prepare("UPDATE kurban SET screen=:komut , keylog=:komut1 WHERE macadres=:id");			//verimizi güncellemek için
					$guncelle->execute([':komut' => $bos,':id'=>$cekilen_id,':komut1'=>$bos]);
					
					header("Location:kurbanlarizle.php?id=".$cekilen_id);
		
		
		?>
		<?php}ob_end_flush();?>